"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Search, ChevronLeft, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";

// Sample blog post data
const blogPosts = [
  {
    id: 1,
    title: "Getting Started with Next.js",
    excerpt:
      "Learn how to set up a Next.js project from scratch and explore its key features for building modern web applications.",
    date: "May 15, 2024",
    image: "/placeholder.svg?height=400&width=600",
    category: "Tutorials",
  },
  {
    id: 2,
    title: "The Power of Server Components",
    excerpt:
      "Discover how React Server Components can improve performance and user experience in your Next.js applications.",
    date: "June 2, 2024",
    image: "/placeholder.svg?height=400&width=600",
    category: "Tech",
  },
  {
    id: 3,
    title: "Optimizing Images in Next.js",
    excerpt:
      "Learn best practices for image optimization in Next.js to improve loading times and user experience.",
    date: "June 18, 2024",
    image: "/placeholder.svg?height=400&width=600",
    category: "Tutorials",
  },
  {
    id: 4,
    title: "Building a Portfolio with Next.js",
    excerpt:
      "A step-by-step guide to creating a professional portfolio website using Next.js and Tailwind CSS.",
    date: "July 5, 2024",
    image: "/placeholder.svg?height=400&width=600",
    category: "Tutorials",
  },
  {
    id: 5,
    title: "The Future of Web Development",
    excerpt:
      "Exploring emerging trends and technologies that will shape the future of web development in the coming years.",
    date: "July 22, 2024",
    image: "/placeholder.svg?height=400&width=600",
    category: "Tech",
  },
  {
    id: 6,
    title: "From Junior to Senior Developer",
    excerpt:
      "Key skills and practices that can help you progress from a junior to a senior developer role in your career.",
    date: "August 10, 2024",
    image: "/placeholder.svg?height=400&width=600",
    category: "Career",
  },
  {
    id: 7,
    title: "Understanding TypeScript Generics",
    excerpt:
      "A deep dive into TypeScript generics and how they can make your code more reusable and type-safe.",
    date: "August 28, 2024",
    image: "/placeholder.svg?height=400&width=600",
    category: "Tech",
  },
  {
    id: 8,
    title: "Accessibility in Web Development",
    excerpt:
      "Best practices for making your web applications accessible to all users, including those with disabilities.",
    date: "September 15, 2024",
    image: "/placeholder.svg?height=400&width=600",
    category: "Tutorials",
  },
  {
    id: 9,
    title: "State Management in React",
    excerpt:
      "Comparing different state management solutions in React and when to use each one in your projects.",
    date: "October 5, 2024",
    image: "/placeholder.svg?height=400&width=600",
    category: "Tech",
  },
];

const categories = ["All", "Tech", "Tutorials", "Career"];

export default function BlogPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [currentPage, setCurrentPage] = useState(1);
  const [filteredPosts, setFilteredPosts] = useState(blogPosts);
  const postsPerPage = 6;

  useEffect(() => {
    let result = blogPosts;

    // Filter by search term
    if (searchTerm) {
      result = result.filter(
        (post) =>
          post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          post.excerpt.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filter by category
    if (selectedCategory !== "All") {
      result = result.filter((post) => post.category === selectedCategory);
    }

    setFilteredPosts(result);
    setCurrentPage(1); // Reset to first page when filters change
  }, [searchTerm, selectedCategory]);

  // Calculate pagination
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = filteredPosts.slice(indexOfFirstPost, indexOfLastPost);
  const totalPages = Math.ceil(filteredPosts.length / postsPerPage);

  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="container py-12 px-4 md:px-6">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Main Content */}
        <div className="w-full md:w-2/3">
          <h1 className="text-4xl font-bold mb-6">Blog</h1>
          <p className="text-lg text-muted-foreground mb-8">
            Thoughts, tutorials, and insights about web development and
            technology.
          </p>

          {/* Blog Posts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {currentPosts.length > 0 ? (
              currentPosts.map((post) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  whileHover={{ y: -5 }}
                  className="group"
                >
                  <Card className="h-full overflow-hidden">
                    <div className="aspect-video relative overflow-hidden">
                      <Image
                        src={post.image || "/placeholder.svg"}
                        alt={post.title}
                        fill
                        className="object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                    </div>
                    <CardContent className="p-5">
                      <div className="flex justify-between items-center mb-2">
                        <Badge variant="secondary">{post.category}</Badge>
                        <span className="text-sm text-muted-foreground">
                          {post.date}
                        </span>
                      </div>
                      <Link href={`/blog/1`}>
                        <h2 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                          {post.title}
                        </h2>
                      </Link>
                      <p className="text-muted-foreground line-clamp-3">
                        {post.excerpt}
                      </p>
                      <Button
                        asChild
                        variant="link"
                        className="p-0 mt-2 h-auto font-semibold"
                      >
                        <Link href={`/blog/1`}>Read More</Link>
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))
            ) : (
              <div className="col-span-2 text-center py-12">
                <p className="text-lg text-muted-foreground">
                  No posts found matching your criteria.
                </p>
              </div>
            )}
          </div>

          {/* Pagination */}
          {filteredPosts.length > postsPerPage && (
            <div className="flex justify-center items-center gap-2 mt-8">
              <Button
                variant="outline"
                size="icon"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (number) => (
                  <Button
                    key={number}
                    variant={currentPage === number ? "default" : "outline"}
                    onClick={() => handlePageChange(number)}
                    className="w-10 h-10"
                  >
                    {number}
                  </Button>
                )
              )}
              <Button
                variant="outline"
                size="icon"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="w-full md:w-1/3 space-y-8">
          {/* Search */}
          <div className="border rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Search</h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search posts..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          {/* Categories */}
          <div className="border rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Categories</h3>
            <div className="space-y-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          {/* Newsletter */}
          <div className="border rounded-lg p-6 bg-muted/50">
            <h3 className="text-lg font-semibold mb-2">Newsletter</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Subscribe to get the latest posts delivered directly to your
              inbox.
            </p>
            <div className="space-y-2">
              <Input placeholder="Your email address" />
              <Button className="w-full">Subscribe</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
