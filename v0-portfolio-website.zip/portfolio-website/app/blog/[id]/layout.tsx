import type React from "react";
import type { Metadata } from "next";

// Sample blog post data for metadata
const blogPosts = [
  {
    id: "1",
    title: "Getting Started with Next.js",
    excerpt:
      "Learn how to set up a Next.js project from scratch and explore its key features for building modern web applications.",
  },
  {
    id: "2",
    title: "The Power of Server Components",
    excerpt:
      "Discover how React Server Components can improve performance and user experience in your Next.js applications.",
  },
  {
    id: "3",
    title: "Optimizing Images in Next.js",
    excerpt:
      "Learn best practices for image optimization in Next.js to improve loading times and user experience.",
  },
  {
    id: "4",
    title: "Building a Portfolio with Next.js",
    excerpt:
      "A step-by-step guide to creating a professional portfolio website using Next.js and Tailwind CSS.",
  },
];

type Props = {
  params: { id: string };
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  // Find the post with the matching ID
  const { id } = await params;
  const post = blogPosts.find((post) => post.id === id);

  if (!post) {
    return {
      title: "Blog Post Not Found",
      description:
        "The blog post you're looking for doesn't exist or has been removed.",
    };
  }

  return {
    title: `${post.title} | Portfolio Blog`,
    description: post.excerpt,
    openGraph: {
      title: post.title,
      description: post.excerpt,
      type: "article",
    },
  };
}

export default function BlogPostLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return <>{children}</>;
}
