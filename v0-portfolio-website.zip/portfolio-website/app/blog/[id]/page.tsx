"use client";

import { useEffect, useState, useRef, use } from "react";
import Image from "next/image";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ChevronUp, Clock, Calendar, ArrowLeft } from "lucide-react";
import { motion } from "framer-motion";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { tomorrow } from "react-syntax-highlighter/dist/esm/styles/prism";
import { cn } from "@/lib/utils";

// Sample blog post data
const blogPosts = [
  {
    id: "1",
    title: "Getting Started with Next.js",
    excerpt:
      "Learn how to set up a Next.js project from scratch and explore its key features for building modern web applications.",
    date: "May 15, 2023",
    readingTime: "8 min read",
    category: "Tutorials",
    image: "/placeholder.svg?height=600&width=1200",
    content: ``,
    headings: [
      {
        id: "introduction-to-nextjs",
        text: "Introduction to Next.js",
        level: 2,
      },
      { id: "why-choose-nextjs", text: "Why Choose Next.js?", level: 3 },
      { id: "getting-started", text: "Getting Started", level: 2 },
      { id: "project-structure", text: "Project Structure", level: 3 },
      { id: "creating-pages", text: "Creating Pages", level: 2 },
      { id: "data-fetching", text: "Data Fetching", level: 2 },
      { id: "server-components", text: "Server Components", level: 3 },
      { id: "client-components", text: "Client Components", level: 3 },
      { id: "conclusion", text: "Conclusion", level: 2 },
    ],
    relatedPosts: [2, 3, 4],
  },
  {
    id: "2",
    title: "The Power of Server Components",
    excerpt:
      "Discover how React Server Components can improve performance and user experience in your Next.js applications.",
    date: "June 2, 2023",
    readingTime: "10 min read",
    category: "Tech",
    image: "/placeholder.svg?height=400&width=600",
    content: ``,
    headings: [
      {
        id: "understanding-server-components",
        text: "Understanding Server Components",
        level: 2,
      },
      {
        id: "benefits-of-server-components",
        text: "Benefits of Server Components",
        level: 3,
      },
      {
        id: "implementation-in-nextjs",
        text: "Implementation in Next.js",
        level: 2,
      },
      {
        id: "client-vs-server-components",
        text: "Client vs Server Components",
        level: 2,
      },
      {
        id: "when-to-use-server-components",
        text: "When to Use Server Components",
        level: 3,
      },
      {
        id: "when-to-use-client-components",
        text: "When to Use Client Components",
        level: 3,
      },
      { id: "conclusion", text: "Conclusion", level: 2 },
    ],
    relatedPosts: [1, 3, 5],
  },
  {
    id: "3",
    title: "Optimizing Images in Next.js",
    excerpt:
      "Learn best practices for image optimization in Next.js to improve loading times and user experience.",
    date: "June 18, 2023",
    readingTime: "6 min read",
    category: "Tutorials",
    image: "/placeholder.svg?height=400&width=600",
    content: ``,
    headings: [
      {
        id: "the-importance-of-image-optimization",
        text: "The Importance of Image Optimization",
        level: 2,
      },
      {
        id: "using-the-nextjs-image-component",
        text: "Using the Next.js Image Component",
        level: 2,
      },
      {
        id: "key-features-of-the-image-component",
        text: "Key Features of the Image Component",
        level: 2,
      },
      { id: "best-practices", text: "Best Practices", level: 2 },
      { id: "conclusion", text: "Conclusion", level: 2 },
    ],
    relatedPosts: [1, 2, 4],
  },
  {
    id: "4",
    title: "Building a Portfolio with Next.js",
    excerpt:
      "A step-by-step guide to creating a professional portfolio website using Next.js and Tailwind CSS.",
    date: "July 5, 2023",
    readingTime: "12 min read",
    category: "Tutorials",
    image: "/placeholder.svg?height=400&width=600",
    content: ``,
    headings: [
      {
        id: "planning-your-portfolio",
        text: "Planning Your Portfolio",
        level: 2,
      },
      {
        id: "setting-up-the-project",
        text: "Setting Up the Project",
        level: 2,
      },
      { id: "creating-the-layout", text: "Creating the Layout", level: 2 },
      { id: "building-key-sections", text: "Building Key Sections", level: 2 },
      { id: "home-page", text: "Home Page", level: 3 },
      { id: "about-page", text: "About Page", level: 3 },
      { id: "projects-page", text: "Projects Page", level: 3 },
      { id: "contact-page", text: "Contact Page", level: 3 },
      { id: "deployment", text: "Deployment", level: 2 },
      { id: "conclusion", text: "Conclusion", level: 2 },
    ],
    relatedPosts: [1, 3, 5],
  },
];

export default function BlogPostPage({ params }: { params: { id: string } }) {
  const { id } = use(params);
  const post = blogPosts.find((post) => post.id === id);
  const [activeHeading, setActiveHeading] = useState("");
  const [showBackToTop, setShowBackToTop] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);
  const headingRefs = useRef<{ [key: string]: HTMLElement | null }>({});

  useEffect(() => {
    // Set up intersection observer for headings
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveHeading(entry.target.id);
          }
        });
      },
      { rootMargin: "-100px 0px -80% 0px" }
    );

    // Observe all headings
    if (post && post.headings) {
      post.headings.forEach((heading) => {
        const element = document.getElementById(heading.id);
        if (element) {
          headingRefs.current[heading.id] = element;
          observer.observe(element);
        }
      });
    }

    // Set up scroll listener for back-to-top button
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setShowBackToTop(true);
      } else {
        setShowBackToTop(false);
      }
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      // Clean up observers and listeners
      if (post && post.headings) {
        post.headings.forEach((heading) => {
          const element = headingRefs.current[heading.id];
          if (element) {
            observer.unobserve(element);
          }
        });
      }
      window.removeEventListener("scroll", handleScroll);
    };
  }, [post]);

  const scrollToHeading = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 100,
        behavior: "smooth",
      });
    }
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  if (!post) {
    return (
      <div className="container py-20 text-center">
        <h1 className="text-3xl font-bold mb-4">Blog Post Not Found</h1>
        <p className="mb-8">
          The blog post you're looking for doesn't exist or has been removed.
        </p>
        <Button asChild>
          <Link href="/blog">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Blog
          </Link>
        </Button>
      </div>
    );
  }

  // Find related posts
  const relatedPosts = post.relatedPosts
    ? post.relatedPosts
        .map((id) => blogPosts.find((p) => p.id === id.toString()))
        .filter(Boolean)
    : [];

  return (
    <>
      {/* SEO Meta Tags would go here */}
      <div className="container py-12 px-4 md:px-6">
        <div className="max-w-4xl mx-auto mb-8">
          <Button asChild variant="ghost" className="mb-6">
            <Link href="/blog">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Blog
            </Link>
          </Button>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Main Content */}
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="w-full lg:w-3/4"
          >
            {/* Featured Image */}
            <div className="relative w-full h-[300px] md:h-[400px] rounded-lg overflow-hidden mb-8">
              <Image
                src={post.image || "/placeholder.svg"}
                alt={post.title}
                fill
                className="object-cover"
                priority
              />
            </div>

            {/* Post Header */}
            <header className="mb-8">
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 font-serif">
                {post.title}
              </h1>
              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <Calendar className="mr-1 h-4 w-4" />
                  <span>{post.date}</span>
                </div>
                <div className="flex items-center">
                  <Clock className="mr-1 h-4 w-4" />
                  <span>{post.readingTime}</span>
                </div>
                <Badge className="bg-orange-500 hover:bg-orange-600">
                  {post.category}
                </Badge>
              </div>
            </header>

            {/* Post Content */}
            <div
              ref={contentRef}
              className="prose prose-lg max-w-none font-serif"
            >
              {/* Mobile Table of Contents (Accordion) */}
              <div className="lg:hidden mb-8">
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="toc">
                    <AccordionTrigger className="text-lg font-medium">
                      Table of Contents
                    </AccordionTrigger>
                    <AccordionContent>
                      <nav className="space-y-2">
                        {post.headings &&
                          post.headings.map((heading) => (
                            <button
                              key={heading.id}
                              onClick={() => scrollToHeading(heading.id)}
                              className={cn(
                                "block text-left w-full py-1 px-2 rounded-md text-sm transition-colors",
                                heading.level === 3 && "pl-4",
                                activeHeading === heading.id
                                  ? "bg-orange-100 text-orange-700 font-medium"
                                  : "hover:bg-muted"
                              )}
                            >
                              {heading.text}
                            </button>
                          ))}
                      </nav>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>

              {/* Custom Styled Content */}
              <div className="prose prose-lg blog-content space-y-6">
                {/* Introduction */}
                <h2
                  id="introduction-to-nextjs"
                  className="text-2xl font-bold mt-8 mb-4 font-sans"
                >
                  Introduction to Next.js
                </h2>
                <p className="leading-relaxed">
                  Next.js is a React framework that enables server-side
                  rendering, static site generation, and more. It's designed to
                  make building React applications easier and more efficient.
                </p>

                <h3
                  id="why-choose-nextjs"
                  className="text-xl font-bold mt-6 mb-3 font-sans"
                >
                  Why Choose Next.js?
                </h3>
                <p className="leading-relaxed">
                  There are several reasons why Next.js has become a popular
                  choice for building web applications:
                </p>
                <ol className="list-decimal pl-6 space-y-2 my-4">
                  <li className="leading-relaxed">
                    <strong>Server-side Rendering (SSR):</strong> Next.js allows
                    you to render your React components on the server before
                    sending them to the client. This can improve performance and
                    SEO.
                  </li>
                  <li className="leading-relaxed">
                    <strong>Static Site Generation (SSG):</strong> Next.js can
                    generate static HTML pages at build time, which can be
                    served directly from a CDN for maximum performance.
                  </li>
                  <li className="leading-relaxed">
                    <strong>File-based Routing:</strong> Next.js uses a
                    file-based routing system, which makes it easy to create new
                    pages and routes.
                  </li>
                  <li className="leading-relaxed">
                    <strong>API Routes:</strong> Next.js allows you to create
                    API endpoints as part of your application, making it easy to
                    build full-stack applications.
                  </li>
                </ol>

                <blockquote className="border-l-4 border-orange-500 pl-4 py-2 my-6 italic bg-orange-50 rounded-r-md">
                  "Next.js is the React framework of choice for many developers
                  due to its flexibility and powerful features."
                </blockquote>

                <h2
                  id="getting-started"
                  className="text-2xl font-bold mt-8 mb-4 font-sans"
                >
                  Getting Started
                </h2>
                <p className="leading-relaxed">
                  To create a new Next.js application, you can use the{" "}
                  <code className="bg-gray-100 px-1 py-0.5 rounded font-mono text-sm">
                    create-next-app
                  </code>{" "}
                  command:
                </p>

                <SyntaxHighlighter
                  language="bash"
                  style={tomorrow}
                  className="rounded-md my-4"
                >
                  {`npx create-next-app@latest my-next-app`}
                </SyntaxHighlighter>

                <p className="leading-relaxed">
                  This will create a new Next.js application in the{" "}
                  <code className="bg-gray-100 px-1 py-0.5 rounded font-mono text-sm">
                    my-next-app
                  </code>{" "}
                  directory. You can then navigate to that directory and start
                  the development server:
                </p>

                <SyntaxHighlighter
                  language="bash"
                  style={tomorrow}
                  className="rounded-md my-4"
                >
                  {`cd my-next-app\nnpm run dev`}
                </SyntaxHighlighter>

                <h3
                  id="project-structure"
                  className="text-xl font-bold mt-6 mb-3 font-sans"
                >
                  Project Structure
                </h3>
                <p className="leading-relaxed">
                  A typical Next.js project has the following structure:
                </p>

                <SyntaxHighlighter
                  language="text"
                  style={tomorrow}
                  className="rounded-md my-4"
                >
                  {`my-next-app/
├── app/
│   ├── layout.tsx
│   ├── page.tsx
│   └── ...
├── public/
│   ├── images/
│   └── ...
├── components/
│   └── ...
├── styles/
│   └── ...
├── next.config.js
└── package.json`}
                </SyntaxHighlighter>

                <h2
                  id="creating-pages"
                  className="text-2xl font-bold mt-8 mb-4 font-sans"
                >
                  Creating Pages
                </h2>
                <p className="leading-relaxed">
                  In Next.js, you can create pages by adding files to the{" "}
                  <code className="bg-gray-100 px-1 py-0.5 rounded font-mono text-sm">
                    app
                  </code>{" "}
                  directory. For example, to create a page at the URL{" "}
                  <code className="bg-gray-100 px-1 py-0.5 rounded font-mono text-sm">
                    /about
                  </code>
                  , you would create a file at{" "}
                  <code className="bg-gray-100 px-1 py-0.5 rounded font-mono text-sm">
                    app/about/page.tsx
                  </code>
                  :
                </p>

                <SyntaxHighlighter
                  language="jsx"
                  style={tomorrow}
                  className="rounded-md my-4"
                >
                  {`export default function AboutPage() {
  return (
    <div>
      <h1>About Us</h1>
      <p>This is the about page.</p>
    </div>
  );
}`}
                </SyntaxHighlighter>

                <h2
                  id="data-fetching"
                  className="text-2xl font-bold mt-8 mb-4 font-sans"
                >
                  Data Fetching
                </h2>
                <p className="leading-relaxed">
                  Next.js provides several ways to fetch data for your pages:
                </p>

                <h3
                  id="server-components"
                  className="text-xl font-bold mt-6 mb-3 font-sans"
                >
                  Server Components
                </h3>
                <p className="leading-relaxed">
                  With React Server Components, you can fetch data directly in
                  your components:
                </p>

                <SyntaxHighlighter
                  language="jsx"
                  style={tomorrow}
                  className="rounded-md my-4"
                >
                  {`async function getData() {
  const res = await fetch('https://api.example.com/data');
  return res.json();
}

export default async function Page() {
  const data = await getData();
  
  return (
    <div>
      <h1>{data.title}</h1>
      <p>{data.description}</p>
    </div>
  );
}`}
                </SyntaxHighlighter>

                <div className="my-8">
                  <Image
                    src="/placeholder.svg?height=400&width=800"
                    alt="Data Fetching in Next.js"
                    width={800}
                    height={400}
                    className="rounded-lg mx-auto"
                  />
                  <p className="text-center text-sm text-muted-foreground mt-2">
                    Data Fetching in Next.js
                  </p>
                </div>

                <h3
                  id="client-components"
                  className="text-xl font-bold mt-6 mb-3 font-sans"
                >
                  Client Components
                </h3>
                <p className="leading-relaxed">
                  For client-side data fetching, you can use the{" "}
                  <code className="bg-gray-100 px-1 py-0.5 rounded font-mono text-sm">
                    use client
                  </code>{" "}
                  directive and React hooks:
                </p>

                <SyntaxHighlighter
                  language="jsx"
                  style={tomorrow}
                  className="rounded-md my-4"
                >
                  {`'use client';

import { useState, useEffect } from 'react';

export default function ClientComponent() {
  const [data, setData] = useState(null);
  
  useEffect(() => {
    async function fetchData() {
      const res = await fetch('/api/data');
      const json = await res.json();
      setData(json);
    }
    
    fetchData();
  }, []);
  
  if (!data) return <div>Loading...</div>;
  
  return (
    <div>
      <h1>{data.title}</h1>
      <p>{data.description}</p>
    </div>
  );
}`}
                </SyntaxHighlighter>

                <h2
                  id="conclusion"
                  className="text-2xl font-bold mt-8 mb-4 font-sans"
                >
                  Conclusion
                </h2>
                <p className="leading-relaxed">
                  Next.js provides a powerful and flexible framework for
                  building React applications. With features like server-side
                  rendering, static site generation, and API routes, it's a
                  great choice for building modern web applications.
                </p>
                <p className="leading-relaxed">
                  In future posts, we'll explore more advanced features of
                  Next.js, such as internationalization, authentication, and
                  deployment strategies.
                </p>
              </div>
            </div>

            {/* Related Posts */}
            <section className="mt-16 pt-8 border-t">
              <h2 className="text-2xl font-bold mb-6">Related Posts</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {relatedPosts && relatedPosts.length > 0 ? (
                  relatedPosts.map(
                    (relatedPost) =>
                      relatedPost && (
                        <Card
                          key={relatedPost.id}
                          className="h-full overflow-hidden hover:shadow-md transition-shadow"
                        >
                          <div className="aspect-video relative">
                            <Image
                              src={relatedPost.image || "/placeholder.svg"}
                              alt={relatedPost.title}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <CardContent className="p-5">
                            <Badge variant="secondary" className="mb-2">
                              {relatedPost.category}
                            </Badge>
                            <Link href={`/blog/1`}>
                              <h3 className="text-lg font-bold mb-2 hover:text-orange-500 transition-colors">
                                {relatedPost.title}
                              </h3>
                            </Link>
                            <p className="text-sm text-muted-foreground line-clamp-2">
                              {relatedPost.excerpt}
                            </p>
                          </CardContent>
                        </Card>
                      )
                  )
                ) : (
                  <div className="col-span-3 text-center py-8">
                    <p className="text-muted-foreground">
                      No related posts found.
                    </p>
                  </div>
                )}
              </div>
            </section>
          </motion.article>

          {/* Sidebar - Table of Contents (Desktop) */}
          <aside className="w-full lg:w-1/4 hidden lg:block">
            <div className="sticky top-24 bg-background p-6 rounded-lg border">
              <h3 className="text-lg font-bold mb-4">Table of Contents</h3>
              <nav className="space-y-2">
                {post.headings &&
                  post.headings.map((heading) => (
                    <button
                      key={heading.id}
                      onClick={() => scrollToHeading(heading.id)}
                      className={cn(
                        "block text-left w-full py-1 px-2 rounded-md text-sm transition-colors",
                        heading.level === 3 && "pl-4",
                        activeHeading === heading.id
                          ? "bg-orange-100 text-orange-700 font-medium"
                          : "hover:bg-muted"
                      )}
                    >
                      {heading.text}
                    </button>
                  ))}
              </nav>
            </div>
          </aside>
        </div>
      </div>

      {/* Back to Top Button */}
      <motion.button
        className="fixed bottom-8 right-8 p-3 rounded-full bg-blue-500 text-white shadow-lg z-50"
        onClick={scrollToTop}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{
          opacity: showBackToTop ? 1 : 0,
          scale: showBackToTop ? 1 : 0.8,
          pointerEvents: showBackToTop ? "auto" : "none",
        }}
        transition={{ duration: 0.2 }}
        aria-label="Back to top"
      >
        <ChevronUp className="h-5 w-5" />
      </motion.button>
    </>
  );
}
