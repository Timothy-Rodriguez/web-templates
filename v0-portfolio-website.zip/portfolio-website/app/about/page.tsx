"use client"

import { useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, Briefcase, GraduationCap } from "lucide-react"
import { motion, useAnimation } from "framer-motion"
import { useInView } from "react-intersection-observer"

const skills = [
  "JavaScript",
  "TypeScript",
  "React",
  "Next.js",
  "Node.js",
  "Express",
  "MongoDB",
  "PostgreSQL",
  "GraphQL",
  "Tailwind CSS",
  "HTML",
  "CSS",
  "Git",
  "Docker",
  "AWS",
]

const experiences = [
  {
    id: 1,
    title: "Senior Frontend Developer",
    company: "Tech Solutions Inc.",
    period: "2021 - Present",
    description:
      "Led the development of responsive web applications using React and Next.js. Implemented state management solutions and optimized performance.",
    icon: <Briefcase className="h-5 w-5" />,
  },
  {
    id: 2,
    title: "Frontend Developer",
    company: "Digital Innovations",
    period: "2018 - 2021",
    description:
      "Developed and maintained client websites. Collaborated with designers to implement responsive UI components.",
    icon: <Briefcase className="h-5 w-5" />,
  },
  {
    id: 3,
    title: "Web Development Intern",
    company: "StartUp Hub",
    period: "2017 - 2018",
    description:
      "Assisted in the development of web applications. Gained experience with modern JavaScript frameworks.",
    icon: <Briefcase className="h-5 w-5" />,
  },
]

const education = [
  {
    id: 1,
    degree: "Master of Computer Science",
    institution: "Tech University",
    period: "2016 - 2018",
    description: "Specialized in Web Technologies and Software Engineering.",
    icon: <GraduationCap className="h-5 w-5" />,
  },
  {
    id: 2,
    degree: "Bachelor of Computer Science",
    institution: "State University",
    period: "2012 - 2016",
    description: "Focused on Programming and Software Development fundamentals.",
    icon: <GraduationCap className="h-5 w-5" />,
  },
]

export default function AboutPage() {
  const controls = useAnimation()
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  useEffect(() => {
    if (inView) {
      controls.start("visible")
    }
  }, [controls, inView])

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5,
      },
    },
  }

  return (
    <div className="container py-12 px-4 md:px-6">
      {/* Bio Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex flex-col md:flex-row gap-8 items-center mb-16"
      >
        <div className="w-full md:w-1/3 flex justify-center">
          <div className="relative w-64 h-64 rounded-full overflow-hidden border-4 border-primary/20">
            <Image src="/placeholder.svg?height=256&width=256" alt="Profile" fill className="object-cover" />
          </div>
        </div>
        <div className="w-full md:w-2/3">
          <h1 className="text-4xl font-bold mb-4">About Me</h1>
          <p className="text-lg mb-4">
            I'm a passionate Software Developer with over 5 years of experience building web applications. I specialize
            in creating responsive, user-friendly interfaces using modern JavaScript frameworks like React and Next.js.
          </p>
          <p className="text-lg mb-6">
            My approach combines technical expertise with a keen eye for design, ensuring that the applications I build
            are not only functional but also provide an excellent user experience. I'm constantly learning and exploring
            new technologies to stay at the forefront of web development.
          </p>
          <Button asChild>
            <Link href="#">
              <Download className="mr-2 h-4 w-4" />
              Download Resume
            </Link>
          </Button>
        </div>
      </motion.section>

      {/* Skills Section */}
      <motion.section ref={ref} initial="hidden" animate={controls} variants={containerVariants} className="mb-16">
        <h2 className="text-3xl font-bold mb-6">Skills</h2>
        <div className="flex flex-wrap gap-2">
          {skills.map((skill, index) => (
            <motion.div key={skill} variants={itemVariants}>
              <Badge className="px-3 py-1 text-sm font-medium transition-all hover:scale-105">{skill}</Badge>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* Experience Section */}
      <motion.section initial="hidden" animate={controls} variants={containerVariants} className="mb-16">
        <h2 className="text-3xl font-bold mb-6">Experience</h2>
        <div className="space-y-6">
          {experiences.map((exp) => (
            <motion.div
              key={exp.id}
              variants={itemVariants}
              className="flex gap-4 p-4 rounded-lg border hover:shadow-md transition-all"
            >
              <div className="mt-1 p-2 bg-primary/10 rounded-full text-primary">{exp.icon}</div>
              <div>
                <h3 className="text-xl font-semibold">{exp.title}</h3>
                <p className="text-sm text-muted-foreground mb-1">
                  {exp.company} | {exp.period}
                </p>
                <p>{exp.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* Education Section */}
      <motion.section initial="hidden" animate={controls} variants={containerVariants}>
        <h2 className="text-3xl font-bold mb-6">Education</h2>
        <div className="space-y-6">
          {education.map((edu) => (
            <motion.div
              key={edu.id}
              variants={itemVariants}
              className="flex gap-4 p-4 rounded-lg border hover:shadow-md transition-all"
            >
              <div className="mt-1 p-2 bg-primary/10 rounded-full text-primary">{edu.icon}</div>
              <div>
                <h3 className="text-xl font-semibold">{edu.degree}</h3>
                <p className="text-sm text-muted-foreground mb-1">
                  {edu.institution} | {edu.period}
                </p>
                <p>{edu.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.section>
    </div>
  )
}
