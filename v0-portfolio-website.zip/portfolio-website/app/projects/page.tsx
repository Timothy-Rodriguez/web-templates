"use client"

import { useState, useEffect } from "react"
import ProjectCard from "@/components/project-card"
import { Button } from "@/components/ui/button"
import { motion, AnimatePresence } from "framer-motion"

// Sample project data
const projects = [
  {
    id: 1,
    title: "E-commerce Platform",
    description:
      "A full-stack e-commerce platform with product management, cart functionality, and payment processing.",
    image: "/placeholder.svg?height=600&width=800",
    tags: ["React", "Node.js", "MongoDB"],
    category: "Web Development",
    demoUrl: "#",
    githubUrl: "#",
  },
  {
    id: 2,
    title: "Task Management App",
    description: "A collaborative task management application with real-time updates and team functionality.",
    image: "/placeholder.svg?height=600&width=800",
    tags: ["Next.js", "Firebase", "Tailwind CSS"],
    category: "Web Development",
    demoUrl: "#",
    githubUrl: "#",
  },
  {
    id: 3,
    title: "Portfolio Website",
    description: "A responsive portfolio website showcasing projects and skills with a modern design.",
    image: "/placeholder.svg?height=600&width=800",
    tags: ["React", "Tailwind CSS", "Framer Motion"],
    category: "Web Development",
    demoUrl: "#",
    githubUrl: "#",
  },
  {
    id: 4,
    title: "Weather App",
    description: "A mobile application that provides real-time weather forecasts based on user location.",
    image: "/placeholder.svg?height=600&width=800",
    tags: ["React Native", "API Integration"],
    category: "Mobile Apps",
    demoUrl: "#",
    githubUrl: "#",
  },
  {
    id: 5,
    title: "Blog Platform",
    description: "A content management system for creating and publishing blog posts with user authentication.",
    image: "/placeholder.svg?height=600&width=800",
    tags: ["Next.js", "MongoDB", "Auth.js"],
    category: "Web Development",
    demoUrl: "#",
    githubUrl: "#",
  },
  {
    id: 6,
    title: "Data Visualization Dashboard",
    description: "An interactive dashboard for visualizing complex datasets with filtering capabilities.",
    image: "/placeholder.svg?height=600&width=800",
    tags: ["React", "D3.js", "TypeScript"],
    category: "Data Visualization",
    demoUrl: "#",
    githubUrl: "#",
  },
  {
    id: 7,
    title: "Recipe Finder",
    description: "A web application that helps users find recipes based on available ingredients.",
    image: "/placeholder.svg?height=600&width=800",
    tags: ["JavaScript", "API Integration", "CSS"],
    category: "Web Development",
    demoUrl: "#",
    githubUrl: "#",
  },
  {
    id: 8,
    title: "Open Source Library",
    description: "A utility library for JavaScript developers with common functions and helpers.",
    image: "/placeholder.svg?height=600&width=800",
    tags: ["JavaScript", "TypeScript", "NPM"],
    category: "Open Source",
    demoUrl: "#",
    githubUrl: "#",
  },
  {
    id: 9,
    title: "Fitness Tracker",
    description: "A mobile application for tracking workouts, nutrition, and fitness progress.",
    image: "/placeholder.svg?height=600&width=800",
    tags: ["React Native", "Firebase", "Charts"],
    category: "Mobile Apps",
    demoUrl: "#",
    githubUrl: "#",
  },
]

const categories = ["All", "Web Development", "Mobile Apps", "Data Visualization", "Open Source"]

export default function ProjectsPage() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [filteredProjects, setFilteredProjects] = useState(projects)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 500)

    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    if (selectedCategory === "All") {
      setFilteredProjects(projects)
    } else {
      setFilteredProjects(projects.filter((project) => project.category === selectedCategory))
    }
  }, [selectedCategory])

  return (
    <div className="container py-12 px-4 md:px-6">
      <div className="mb-10">
        <h1 className="text-4xl font-bold mb-6">My Projects</h1>
        <p className="text-lg text-muted-foreground mb-8">
          Browse through my latest work across various technologies and domains.
        </p>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              onClick={() => setSelectedCategory(category)}
              className="transition-all"
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Projects Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="rounded-lg border bg-card text-card-foreground shadow-sm h-[400px] animate-pulse" />
          ))}
        </div>
      ) : (
        <AnimatePresence mode="wait">
          <motion.div
            key={selectedCategory}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredProjects.map((project) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: project.id * 0.05 }}
              >
                <ProjectCard
                  title={project.title}
                  description={project.description}
                  image={project.image}
                  tags={project.tags}
                  demoUrl={project.demoUrl}
                  githubUrl={project.githubUrl}
                />
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  )
}
