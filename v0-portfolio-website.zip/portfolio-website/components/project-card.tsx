import Image from "next/image"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Github, ExternalLink } from "lucide-react"
import { cn } from "@/lib/utils"

interface ProjectCardProps {
  title: string
  description: string
  image: string
  tags: string[]
  demoUrl: string
  githubUrl: string
  className?: string
  featured?: boolean
}

export default function ProjectCard({
  title,
  description,
  image,
  tags,
  demoUrl,
  githubUrl,
  className,
  featured = false,
}: ProjectCardProps) {
  return (
    <div
      className={cn(
        "group relative overflow-hidden rounded-lg border bg-background transition-all hover:shadow-md",
        featured ? "md:col-span-2" : "",
        className,
      )}
    >
      <div className="aspect-video w-full overflow-hidden">
        <Image
          src={image || "/placeholder.svg"}
          alt={title}
          width={600}
          height={340}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </div>
      <div className="p-5">
        <h3 className="text-xl font-bold tracking-tight">{title}</h3>
        <div className="mt-2 flex flex-wrap gap-2">
          {tags.map((tag) => (
            <Badge key={tag} variant="secondary">
              {tag}
            </Badge>
          ))}
        </div>
        <p className="mt-3 text-muted-foreground line-clamp-2">{description}</p>
        <div className="mt-4 flex gap-2">
          <Button asChild size="sm">
            <Link href={demoUrl}>
              <ExternalLink className="mr-2 h-4 w-4" />
              View Project
            </Link>
          </Button>
          <Button asChild size="sm" variant="outline">
            <Link href={githubUrl}>
              <Github className="mr-2 h-4 w-4" />
              GitHub
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
